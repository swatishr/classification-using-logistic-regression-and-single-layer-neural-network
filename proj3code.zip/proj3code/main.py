#main.py
#this runs all the classification algo sequentially
from logistic_main import *
from single_layer_NN_main import *
from cnn_main2 import *
print('Running Logistic Regression...\n')
logistic_main
print('\n\n')
print('Running Single Hidden Layer Neural Network...\n\n\n')
single_layer_NN_main
print('\n\n')
print('Running CNN...\n\n\n')
cnn_main2


