
#########################################################################
#CSE574 | Project 3 | Extra Part: Backpropagation
#Description: Implementation of backpropagation in Single hidden layer NN
#########################################################################

from random import random

